<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';

// Build the base query
$query = "SELECT a.*, 
          u.first_name, u.last_name, u.email,
          p.date_of_birth, p.gender, p.blood_type,
          d.specialization
          FROM appointments a
          JOIN users u ON a.patient_id = u.id
          LEFT JOIN patients p ON u.id = p.user_id
          LEFT JOIN doctors d ON a.doctor_id = d.user_id
          WHERE a.doctor_id = ?";

// Add conditions based on filters
$params = [$_SESSION['user_id']];
$conditions = [];

if ($status !== 'all') {
    $conditions[] = "a.status = ?";
    $params[] = $status;
}

if (!empty($date_from)) {
    $conditions[] = "a.appointment_date >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $conditions[] = "a.appointment_date <= ?";
    $params[] = $date_to;
}

if (!empty($search)) {
    $conditions[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR a.reason LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($conditions)) {
    $query .= " AND " . implode(" AND ", $conditions);
}

// Add sorting
$query .= " ORDER BY a.appointment_date DESC, a.appointment_time DESC";

// Pagination setup
$per_page = 10;
$page = $_GET['page'] ?? 1;
$offset = ($page - 1) * $per_page;

// Get total count for pagination - use a separate query without LIMIT/OFFSET
$count_query = str_replace(
    "SELECT a.*", 
    "SELECT COUNT(*) as total", 
    explode("ORDER BY", $query)[0] // Remove ORDER BY for count query
);
$count_stmt = $pdo->prepare($count_query);
$count_stmt->execute($params);
$total_appointments = $count_stmt->fetchColumn();
$total_pages = ceil($total_appointments / $per_page);

// Add pagination to main query - append after executing count query
$query_with_pagination = $query . " LIMIT " . (int)$per_page . " OFFSET " . (int)$offset;

// Fetch appointments with pagination
$stmt = $pdo->prepare($query_with_pagination);
$stmt->execute($params);
$appointments = $stmt->fetchAll();

$page_title = 'Appointments';
include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-lg">
                <div class="card-header p-3" style="background: linear-gradient(195deg, #49a3f1 0%, #1A73E8 100%);">
                    <div class="d-flex justify-content-between align-items-center flex-wrap">
                        <div class="mb-2 mb-md-0">
                            <h5 class="mb-0 text-white font-weight-bold">
                                <i class="fas fa-calendar-check me-2 text-white"></i>
                                Appointments Management
                            </h5>
                            <p class="text-sm text-white opacity-8 mb-0">View and manage all appointments</p>
                        </div>
                        <div class="d-flex gap-2 flex-wrap">
                            <button class="btn btn-white btn-sm" data-bs-toggle="modal" data-bs-target="#newAppointmentModal">
                                <i class="fas fa-plus me-1"></i> New Appointment
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-body border-bottom">
                    <form method="get" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All Statuses</option>
                                <option value="scheduled" <?= $status === 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
                                <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed</option>
                                <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                <option value="no_show" <?= $status === 'no_show' ? 'selected' : '' ?>>No Show</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">From Date</label>
                            <input type="date" name="date_from" class="form-control" value="<?= $date_from ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">To Date</label>
                            <input type="date" name="date_to" class="form-control" value="<?= $date_to ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Search</label>
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Patient or reason..." value="<?= htmlspecialchars($search) ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card-body px-0 pt-0">
                    <div class="table-responsive">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Patient</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Details</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Appointment</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($appointments as $appt): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-2 py-1">
                                                <div>
                                                    <img src="../assets/images/default-avatar.jpg" class="avatar avatar-sm me-3" alt="user">
                                                </div>
                                                <div class="d-flex flex-column justify-content-center">
                                                    <h6 class="mb-0 text-sm"><?= htmlspecialchars($appt['first_name'].' '.$appt['last_name']) ?></h6>
                                                    <p class="text-xs text-secondary mb-0"><?= htmlspecialchars($appt['email']) ?></p>
                                                    <p class="text-xs text-secondary mb-0">
                                                        <?= !empty($appt['date_of_birth']) ? 'DOB: '.date('m/d/Y', strtotime($appt['date_of_birth'])) : '' ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-xs font-weight-bold mb-0">
                                                Gender: <?= !empty($appt['gender']) ? ucfirst($appt['gender']) : 'N/A' ?>
                                            </p>
                                            <p class="text-xs text-secondary mb-0">
                                                Blood Type: <?= !empty($appt['blood_type']) ? $appt['blood_type'] : 'N/A' ?>
                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-xs font-weight-bold mb-0">
                                                <?= date('M j, Y', strtotime($appt['appointment_date'])) ?>
                                                at <?= date('g:i A', strtotime($appt['appointment_time'])) ?>
                                            </p>
                                            <p class="text-xs text-secondary mb-0">
                                                <?= htmlspecialchars($appt['reason']) ?>
                                            </p>
                                        </td>
                                        <td>
                                            <span class="badge badge-sm 
                                                <?= $appt['status'] === 'scheduled' ? 'bg-gradient-primary' : 
                                                   ($appt['status'] === 'completed' ? 'bg-gradient-success' : 
                                                   ($appt['status'] === 'cancelled' ? 'bg-gradient-danger' : 'bg-gradient-warning')) ?>">
                                                <?= ucfirst(str_replace('_', ' ', $appt['status'])) ?>
                                            </span>
                                        </td>
                                        <td class="align-middle text-end">
                                          <div class="d-flex justify-content-end gap-1">
                                              <!-- View Button -->
                                              <button class="btn btn-sm btn-outline-primary view-btn" 
                                                      data-id="<?= $appt['id'] ?>"
                                                      title="View Details">
                                                  <i class="fas fa-eye"></i>
                                              </button>
                                              
                                              <?php if ($appt['status'] === 'scheduled') : ?>
                                                  <!-- Complete Button (only for scheduled appointments) -->
                                                  <button class="btn btn-sm btn-outline-success complete-btn" 
                                                          data-id="<?= $appt['id'] ?>"
                                                          title="Mark as Completed">
                                                      <i class="fas fa-check"></i>
                                                  </button>
                                                  
                                                  <!-- Cancel Button -->
                                                  <button class="btn btn-sm btn-outline-danger cancel-btn" 
                                                          data-id="<?= $appt['id'] ?>"
                                                          title="Cancel Appointment">
                                                      <i class="fas fa-times"></i>
                                                  </button>
                                              <?php endif; ?>
                                          </div>
                                      </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($appointments)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4">
                                            <i class="fas fa-calendar-times fa-2x text-gray-300 mb-3"></i>
                                            <p class="text-muted">No appointments found</p>
                                            <a href="?status=all" class="btn btn-sm btn-primary">Reset Filters</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($total_pages > 1): ?>
                        <nav class="px-4 pt-3">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // View Appointment - Show Details Modal
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const appointmentId = this.getAttribute('data-id');
            fetch(`/api/get_appointment.php?id=${appointmentId}`)
                .then(response => response.json())
                .then(data => {
                    // Populate your modal with data
                    console.log('Appointment details:', data);
                    // Example: $('#appointmentModal').modal('show');
                });
        });
    });

    // Complete Appointment
    document.querySelectorAll('.complete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const appointmentId = this.getAttribute('data-id');
            if (confirm('Mark this appointment as completed?')) {
                updateAppointmentStatus(appointmentId, 'completed');
            }
        });
    });

    // Cancel Appointment
    document.querySelectorAll('.cancel-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const appointmentId = this.getAttribute('data-id');
            const reason = prompt('Please enter cancellation reason:');
            if (reason) {
                updateAppointmentStatus(appointmentId, 'cancelled', reason);
            }
        });
    });

    // Shared function for status updates
    function updateAppointmentStatus(id, status, note = '') {
        fetch('/api/update_appointment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: id,
                status: status,
                note: note
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload(); // Refresh to show changes
            } else {
                alert('Error: ' + (data.message || 'Update failed'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Network error - please try again');
        });
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>