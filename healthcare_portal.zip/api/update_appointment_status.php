<?php
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

try {
    $appointmentId = $_GET['id'] ?? null;
    $status = $_GET['status'] ?? null;
    $reason = json_decode(file_get_contents('php://input'), true)['reason'] ?? null;

    if (!$appointmentId || !$status) {
        throw new Exception('Missing required parameters');
    }

    // Validate status
    $validStatuses = ['scheduled', 'completed', 'cancelled', 'no_show'];
    if (!in_array($status, $validStatuses)) {
        throw new Exception('Invalid status');
    }

    // Update appointment
    $query = "UPDATE appointments SET status = ?";
    $params = [$status];
    
    if ($status === 'cancelled' && $reason) {
        $query .= ", notes = CONCAT(IFNULL(notes, ''), ' Cancellation reason: ', ?)";
        $params[] = $reason;
    }
    
    $query .= " WHERE id = ? AND doctor_id = ?";
    $params[] = $appointmentId;
    $params[] = $_SESSION['user_id'];

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);

    echo json_encode(['success' => $stmt->rowCount() > 0]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}