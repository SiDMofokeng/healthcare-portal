<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_check.php';

header('Content-Type: application/json');

$doctorId = $_GET['doctor_id'] ?? $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare(
        "SELECT 
            a.id,
            CONCAT(a.appointment_date, 'T', a.appointment_time) as start,
            CONCAT(a.appointment_date, 'T', ADDTIME(a.appointment_time, 
                CASE 
                    WHEN a.duration_minutes IS NOT NULL THEN SEC_TO_TIME(a.duration_minutes * 60)
                    ELSE '00:30:00' 
                END
            )) as end,
            CONCAT(u.first_name, ' ', u.last_name) as title,
            a.status,
            a.reason,
            CASE 
                WHEN a.status = 'completed' THEN '#28a745'
                WHEN a.status = 'cancelled' THEN '#dc3545'
                WHEN a.status = 'no_show' THEN '#ffc107'
                ELSE '#007bff'
            END as backgroundColor,
            '#ffffff' as textColor
        FROM appointments a
        JOIN users u ON a.patient_id = u.id
        WHERE a.doctor_id = ?
        AND a.status != 'cancelled'
        AND a.appointment_date BETWEEN CURDATE() - INTERVAL 1 MONTH AND CURDATE() + INTERVAL 3 MONTH"
    );
    $stmt->execute([$doctorId]);
    
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}