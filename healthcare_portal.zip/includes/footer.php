</main>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <?php if (isset($custom_js)): ?>
        <script src="../assets/js/<?= $custom_js ?>"></script>
    <?php endif; ?>
</body>
</html>